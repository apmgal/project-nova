"use client";

import { useState } from "react";
import Image from "next/image";
import SceneAudio from "./narrative/SceneAudio";

interface TitleScreenProps {
  hasSave: boolean;
  onNewGame: () => void;
  onContinue: () => void;
}

// Browsers block audio-with-sound autoplay until the page has a genuine
// user gesture. On a fresh visit (no prior interaction on the domain —
// the common case for a first-time Vercel visitor, unlike local dev where
// the browser usually already has some engagement with localhost) the
// title track's autoplay-on-mount is silently rejected; SceneAudio's own
// fallback then unlocks it on the page's first pointerdown/keydown. The
// trouble is that first gesture is almost always the "Begin Mission"
// click itself, which is also what unmounts TitleScreen — so the track
// gets unlocked and torn down in the same event, audible for a blip if
// at all. Holding the screen mounted for HOLD_MS after the click gives
// the now-unlocked track real time to fade in and be heard before the
// scene actually swaps to Reception Intro. (Update: the title theme now
// fades out as soon as either button is clicked — see the SceneAudio src
// below — so HOLD_MS only keeps the "Starting…" state on screen briefly.)
const HOLD_MS = 1000;

/**
 * Title screen — restyled around a "mission team" cover-art composition,
 * studied from a cartoon game-cover reference (thick white/cream sticker
 * outlines on cutout characters anchored bottom-left, bold poster-lettered
 * title banked upper-right over a flat warm backdrop, single CTA in the
 * open space beneath it). mission_team_v2.png is the reference photo
 * (now with the AstraZeneca logo composited onto the desk) with that
 * sticker-outline treatment applied to the three-person cutout group;
 * --nova-cream-photo matches its baked-in background exactly so
 * there's no visible seam where the image meets the page. Named _v2
 * (not overwriting the original mission_team.png filename) so a
 * cached copy of the old art can never be served in its place.
 *
 * Same props as before — hasSave/onNewGame/onContinue. "Begin Mission"
 * (onNewGame) always shows; "Continue Mission" (onContinue) joins it
 * alongside, only once hasSave is true, rather than the two swapping
 * places as a single button.
 *
 * Previous "Guild of Project Masters" quest-log framing (Mike Elloian's
 * speech bubble, the "Quest Log"/"Guild of Project Masters" eyebrows,
 * MedievalSharp title lettering, the indeterminate "preparing your
 * quest" bar) is gone entirely — this screen no longer uses any "quest"
 * language, imagery, or its own now-unused marcus_fullbody.png cutout.
 *
 * Music: main_title_loop_v2.mp3 is a ~30s clip (with a short fade at
 * each end so the loop seam doesn't click) trimmed from the full
 * Main_title01.mp3 track supplied for this screen. Named _v2 (not
 * main_title_loop.mp3) because the first trim, produced with -ss/-t and
 * the afade filters in one ffmpeg pass, silently went silent after ~10s
 * — trimming and fading in two separate passes fixed the audio itself,
 * and the filename changed too so a stale cached copy of the broken
 * clip can never be served in its place. Reuses SceneAudio — built for
 * the narrative-scene engine but genuinely scene-agnostic (just a
 * src/volume/loop/fade player, no narrative-specific coupling) — for
 * its native `loop` + fade-in/out handling rather than duplicating that
 * logic here. It plays for as long as TitleScreen is mounted; clicking
 * Begin Mission or Continue Mission navigates GameRoot away from this
 * screen, which unmounts TitleScreen (and SceneAudio with it) —
 * SceneAudio's cleanup fades the track out over fadeOutMs on unmount
 * regardless of which button triggered it, so both paths stop the
 * music the same way with no extra wiring here. fadeOutMs is 2000ms
 * (up from an initial 900ms) so it overlaps more of Reception Intro's
 * own 2200ms music fade-in underneath it — a longer, smoother crossfade
 * into Mike's dialogue instead of the title theme cutting out abruptly
 * right as the new scene's track is just getting started.
 */
export default function TitleScreen({ hasSave, onNewGame, onContinue }: TitleScreenProps) {
  const [pending, setPending] = useState<"new" | "continue" | null>(null);

  function handleBegin() {
    if (pending) return;
    setPending("new");
    window.setTimeout(onNewGame, HOLD_MS);
  }

  function handleContinueClick() {
    if (pending) return;
    setPending("continue");
    window.setTimeout(onContinue, HOLD_MS);
  }

  return (
    <div
      className="relative flex flex-1 items-center overflow-hidden"
      style={{ backgroundColor: "var(--nova-cream-photo)" }}
    >
      {/* The title theme stops as soon as Begin Mission / Continue Mission is clicked: dropping
          the src fades it out right away (0.8 s) instead of playing on through the hand-off. */}
      <SceneAudio src={pending ? null : "/assets/music/main_title_loop_v2.mp3"} volume={0.4} loop fadeInMs={1500} fadeOutMs={800} />

      {/* Mission team — sticker-outlined cutout, anchored bottom-left */}
      <div className="pointer-events-none absolute bottom-0 left-0 z-0 h-[62%] w-[72%] sm:h-[80%] sm:w-[48%] md:w-[42%]">
        <div className="relative h-full w-full">
          <Image
            src="/assets/title/mission_team_v2.png"
            alt="The mission team"
            fill
            sizes="620px"
            className="object-contain object-left-bottom drop-shadow-[0_16px_22px_rgba(36,26,30,0.22)]"
            priority
          />
        </div>
      </div>

      {/* Title + CTA column — upper-right, mirroring the reference's banner placement.
          Not `items-end`/`text-right` anymore: the two title lines need
          independent alignment (OPERATION left, NOVA right, per direction —
          the reference's zigzag poster-lettering look), so each element
          below manages its own alignment instead of inheriting one.

          The left-shift offsets on OPERATION/NOVA/tagline+CTAs are in vw,
          not a fixed px or cm amount — they started as literal cm values,
          but those don't scale with screen size (a physical 11cm shift on
          a phone-width screen would push OPERATION almost entirely
          off-canvas), so the whole layout could distort at other window
          sizes even though the font-size clamp()s already scale fine.
          Converted to vw (at the ~1280px width this was tuned at:
          -11cm -> -32.5vw, -2cm -> -5.9vw) so every offset scales with
          the viewport the same way the fonts already do — proportions
          hold at any screen size instead of only the one this was eyeballed
          on. */}
      <div className="relative z-10 ml-auto flex w-full max-w-[560px] flex-col gap-4 px-6 py-8 sm:px-10 sm:py-12">
        {/* Two independent boxes (not just two lines of one block) — a
            real gap between them (gap-5/sm:gap-8) plus each managing its
            own text-align, so OPERATION and NOVA can sit apart and point
            opposite directions rather than reading as one tight lockup. */}
        <h1
          className="flex flex-col gap-5 text-[var(--nova-ink-900)] sm:gap-8"
          style={{ fontFamily: "var(--font-poster)", lineHeight: 0.88 }}
        >
          <div
            className="text-left text-[clamp(4.5rem,12vw,8.5rem)]"
            style={{ textShadow: "3px 4px 0 var(--nova-gold-300)", transform: "translateX(-32.5vw)" }}
          >
            OPERATION
          </div>
          <div
            className="text-right text-[clamp(4.5rem,12vw,8.5rem)]"
            style={{ textShadow: "4px 6px 0 var(--nova-gold-300)", transform: "translateX(-5.9vw)" }}
          >
            NOVA
          </div>
        </h1>

        {/* Tagline + CTA(s), shifted left together (in step with the title
            above, same vw-based scaling) */}
        <div className="flex flex-col items-end gap-4" style={{ transform: "translateX(-5.9vw)" }}>
          <p className="text-right text-[length:var(--text-body-lg)] italic text-[var(--color-text-on-parchment-muted)] [font-family:var(--font-body)]">
            Your mission begins here
          </p>

          <div className="mt-2 flex flex-wrap items-center justify-end gap-4">
            {/* Begin Mission — always shown, always starts a fresh game.
                Disabled (not hidden) while pending, so a slow tap can't
                double-fire and race the HOLD_MS-delayed navigation above. */}
            <button
              onClick={handleBegin}
              disabled={pending !== null}
              className="rounded-[var(--radius-pill)] border-[3px] border-[var(--nova-ink-900)] bg-[var(--color-brand-primary)] px-9 py-3.5 text-[17px] font-extrabold uppercase tracking-[var(--tracking-wide)] text-[var(--color-text-on-brand)] shadow-[4px_4px_0_var(--nova-ink-900)] transition-transform duration-[var(--duration-fast)] ease-[var(--ease-standard)] hover:-translate-y-0.5 hover:shadow-[6px_6px_0_var(--nova-ink-900)] active:translate-y-0.5 active:shadow-[2px_2px_0_var(--nova-ink-900)] disabled:cursor-default disabled:opacity-70 disabled:hover:translate-y-0 disabled:hover:shadow-[4px_4px_0_var(--nova-ink-900)] [font-family:var(--font-body)]"
            >
              {pending === "new" ? "Starting…" : "Begin Mission"}
            </button>

            {/* Continue Mission — alongside Begin Mission, only once a save exists. */}
            {hasSave && (
              <button
                onClick={handleContinueClick}
                disabled={pending !== null}
                className="rounded-[var(--radius-pill)] border-[3px] border-[var(--nova-ink-900)] bg-transparent px-9 py-3.5 text-[17px] font-extrabold uppercase tracking-[var(--tracking-wide)] text-[var(--nova-ink-900)] shadow-[4px_4px_0_var(--nova-ink-900)] transition-transform duration-[var(--duration-fast)] ease-[var(--ease-standard)] hover:-translate-y-0.5 hover:shadow-[6px_6px_0_var(--nova-ink-900)] hover:bg-[var(--nova-parchment-100)] active:translate-y-0.5 active:shadow-[2px_2px_0_var(--nova-ink-900)] disabled:cursor-default disabled:opacity-70 disabled:hover:translate-y-0 disabled:hover:bg-transparent disabled:hover:shadow-[4px_4px_0_var(--nova-ink-900)] [font-family:var(--font-body)]"
              >
                {pending === "continue" ? "Starting…" : "Continue Mission"}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// Act 6 ending resolution — the three-gate model (see data/endings.json for
// the narrative spec and centralised, provisional thresholds this reads,
// and DESIGN_NOTES.md's "Four-family ending architecture" entry for the
// full design rationale). Deliberately a single pure function: no state
// mutation, no persistence of its own — GameState.decisions/.flags/
// .statusReports/.relationships/.projectMetrics are the only inputs, and
// every number this needs already exists there. Call it fresh wherever the
// resolved ending is needed (ACT6_SCENE02's batch result, ACT6_SCENE03's
// ending dialogue, the conditional NHS Procurement notice) rather than
// caching it on GameState — it's cheap and always a pure function of state
// already present, same reasoning as reportMismatchFlags/effectiveDialogueFlags
// in state.ts.

import type { GameState } from "./types";
import { findMostMaterialReportMismatch, computeBudgetReconciliation } from "./state";
import endingsConfig from "@/data/endings.json";

export type ContractGateResult = "secured" | "lost";
export type BatchResult = "released" | "rejected";
export type EndingFamily =
  | "TRIUMPHANT_LAUNCH"
  | "PYRRHIC_VICTORY"
  | "CONTRACT_LOST"
  | "BATCH_REJECTED";
export type PyrrhicVariant = "financial" | "political" | "scrutiny" | "organisational" | "recoverable_quality_failure";

/** Only meaningful when endingVariant === "organisational" — which single
 * dimension contributed the largest weighted shortfall within that bucket,
 * so ACT6_SCENE03's dialogue can pick one honest, specific closing line
 * instead of vaguely gesturing at board/team/trust simultaneously. See
 * evaluateDeliveryComposite's variant-selection block and
 * data/endings.json's variantSelectionNote for how this is chosen. */
export type OrganisationalDominantCause = "boardConfidence" | "teamMorale" | "honesty" | "stakeholderGoodwill";

export interface EndingResult {
  contractGateResult: ContractGateResult;
  /** Null when the Contract Gate already resolved to "lost" — Gate 2 never
   * runs in that case, since the commercial outcome is already decided.
   * This is the field that keeps "batch event" and "ending family"
   * distinct: a rejected-then-recovered batch can still resolve to the
   * PYRRHIC_VICTORY family (see endingVariant "recoverable_quality_failure"),
   * so code must never infer endingFamily from batchResult alone. */
  batchResult: BatchResult | null;
  endingFamily: EndingFamily;
  /** Only set when endingFamily === "PYRRHIC_VICTORY". */
  endingVariant: PyrrhicVariant | null;
  /** Only set when endingVariant === "organisational"; null otherwise
   * (including for every other Pyrrhic variant). */
  organisationalDominantCause: OrganisationalDominantCause | null;
  /** Human-readable trace of exactly why each gate resolved the way it
   * did — every gate appends one line, in evaluation order, unconditionally
   * (including gates that never ran, so the array's length alone tells you
   * how far evaluation got). Intended for the debug panel and for sanity-
   * checking calibration during playtesting, not for player-facing copy. */
  diagnostics: string[];
}

type EndingsConfig = typeof endingsConfig;
const config: EndingsConfig = endingsConfig;
const gates = config.gateThresholds;

function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

/** consistent=100, borderline=55, material=0 — see deliveryComposite.weightsNote
 * in data/endings.json. Deliberately derived from findMostMaterialReportMismatch
 * on every call rather than tracked separately (see the "honesty tracking"
 * discussion in DESIGN_NOTES.md — reportsAccurate/reportsMisleading counters
 * were considered and rejected as duplicate state). */
function honestySubscore(state: GameState): number {
  const mismatch = findMostMaterialReportMismatch(state);
  if (!mismatch) return 100;
  return mismatch.severity === "material" ? 0 : 55;
}

function evaluateContractGate(state: GameState): { result: ContractGateResult; diagnostic: string } {
  const cfg = gates.contractGate;
  const schedule = state.projectMetrics.scheduleHealth;
  const goodwill = state.projectMetrics.stakeholderGoodwill;

  const graceApplies = state.decisions[cfg.graceDecision.key] === cfg.graceDecision.value;
  const effectiveFloor = graceApplies ? cfg.graceDecision.scheduleHealthFloorOverride : cfg.scheduleHealthFloor;

  const scheduleFailed = schedule < effectiveFloor;
  const investigationDelayedLaunch = goodwill <= cfg.severeGoodwillFloor;

  if (scheduleFailed || investigationDelayedLaunch) {
    const reason = scheduleFailed
      ? `scheduleHealth ${schedule} < floor ${effectiveFloor}${graceApplies ? " (grace applied)" : ""}`
      : `stakeholderGoodwill ${goodwill} <= severe floor ${cfg.severeGoodwillFloor} (external investigation delayed launch)`;
    return {
      result: "lost",
      diagnostic: `Gate 1 (Contract): LOST — ${reason}.`,
    };
  }

  return {
    result: "secured",
    diagnostic: `Gate 1 (Contract): SECURED — scheduleHealth ${schedule} >= floor ${effectiveFloor}${graceApplies ? " (grace applied)" : ""}, stakeholderGoodwill ${goodwill} > severe floor ${cfg.severeGoodwillFloor}.`,
  };
}

/** Exported (unchanged) for the inspection's formal determination, which is this gate. */
export function evaluateQualityGate(
  state: GameState,
): { batchResult: BatchResult; family: "PYRRHIC_VICTORY" | "BATCH_REJECTED" | null; diagnostic: string } {
  const cfg = gates.qualityGate;
  const readiness = state.projectMetrics.regulatoryReadiness;
  const risk = state.projectMetrics.riskExposure;
  const mismatch = findMostMaterialReportMismatch(state);
  const mismatchLabel = mismatch ? mismatch.severity : "consistent";

  const released =
    readiness >= cfg.releaseRegulatoryReadinessFloor &&
    risk <= cfg.releaseRiskExposureCeiling &&
    mismatchLabel !== "material";

  if (released) {
    return {
      batchResult: "released",
      family: null,
      diagnostic: `Gate 2 (Quality): RELEASED — regulatoryReadiness ${readiness} >= ${cfg.releaseRegulatoryReadinessFloor}, riskExposure ${risk} <= ${cfg.releaseRiskExposureCeiling}, mismatch ${mismatchLabel}.`,
    };
  }

  const recoverable = readiness >= cfg.recoverableRegulatoryReadinessFloor && mismatchLabel !== "material";
  if (recoverable) {
    return {
      batchResult: "rejected",
      family: "PYRRHIC_VICTORY",
      diagnostic: `Gate 2 (Quality): REJECTED but RECOVERABLE — regulatoryReadiness ${readiness} >= recoverable floor ${cfg.recoverableRegulatoryReadinessFloor}, mismatch ${mismatchLabel} (not material) → routes to Pyrrhic Victory (recoverable_quality_failure).`,
    };
  }

  return {
    batchResult: "rejected",
    family: "BATCH_REJECTED",
    diagnostic: `Gate 2 (Quality): REJECTED, UNRECOVERABLE — regulatoryReadiness ${readiness} (recoverable floor ${cfg.recoverableRegulatoryReadinessFloor}), mismatch ${mismatchLabel}.`,
  };
}

function evaluateDeliveryComposite(state: GameState): {
  family: EndingFamily;
  variant: PyrrhicVariant;
  organisationalDominantCause: OrganisationalDominantCause | null;
  diagnostic: string;
} {
  const cfg = gates.deliveryComposite;
  const w = cfg.weights;
  const metrics = state.projectMetrics;

  // financialSubscore reads headroom against the £4.0M contingency Act 3
  // establishes, not budgetRemaining against the full £12.0M approved
  // figure — the latter understated exposure (spending exactly the
  // contingency still read as "66% of budget remaining, looks healthy"
  // rather than the true "0% of contingency left"). See
  // computeBudgetReconciliation's own doc comment in state.ts.
  const reconciliation = computeBudgetReconciliation(state);
  const financialSubscore = clamp(
    (reconciliation.headroom / reconciliation.originalContingency) * 100,
    0,
    100
  );
  const goodwill = clamp(metrics.stakeholderGoodwill, 0, 100);
  const morale = clamp(metrics.teamMorale, 0, 100);
  const boardConfidence = clamp(metrics.boardConfidence, 0, 100);
  const honesty = honestySubscore(state);

  // Benefits are deliberately NOT a term here. The old benefitsRealisationScore
  // metric has been retired entirely (no upward path ever existed for it, so it
  // could only ever drag the composite down) — see the weightsNote in
  // data/endings.json. Benefits management is now assessed narratively in Act 6
  // via the Benefits Register artefact, not folded into this numeric composite.
  const composite =
    financialSubscore * w.financialSubscore +
    goodwill * w.stakeholderGoodwill +
    morale * w.teamMorale +
    boardConfidence * w.boardConfidence +
    honesty * w.honesty;

  const compositeSummary = `composite ${composite.toFixed(1)} (financial ${financialSubscore.toFixed(0)}, goodwill ${goodwill}, morale ${morale}, boardConfidence ${boardConfidence}, honesty ${honesty})`;

  // Political isolation is checked BEFORE the composite threshold, not as a
  // fallback once the composite already reads low — a high composite must
  // never be able to average away a cold sponsor/QA relationship into a
  // Triumphant reading (see DESIGN_NOTES.md: "excellent everything else +
  // Camille cold" is exactly the disproportionate-punishment case this
  // design is meant to avoid IN THE OTHER DIRECTION — it can't become a
  // hidden Triumphant either). Uses its own politicalIsolationThreshold,
  // deliberately NOT WARM_RELATIONSHIP_THRESHOLD — see that field's note in
  // data/endings.json for why (a never-cultivated-but-not-damaged default
  // relationship must not read as "isolated").
  const marcusTrust = state.relationships.marcus ?? 0;
  const camilleTrust = state.relationships.camille ?? 0;
  const isolationFloor = cfg.politicalIsolationThreshold;
  const politicallyIsolated = marcusTrust < isolationFloor || camilleTrust < isolationFloor;

  if (politicallyIsolated) {
    return {
      family: "PYRRHIC_VICTORY",
      variant: "political",
      organisationalDominantCause: null,
      diagnostic: `Gate 3 (Delivery): PYRRHIC / political — min(marcus ${marcusTrust}, camille ${camilleTrust}) < politicalIsolationThreshold ${isolationFloor} (checked before the composite; ${compositeSummary} not decisive here).`,
    };
  }

  if (composite >= cfg.triumphantThreshold) {
    return {
      family: "TRIUMPHANT_LAUNCH",
      variant: "financial", // unused when family isn't Pyrrhic; see EndingResult.endingVariant
      organisationalDominantCause: null,
      diagnostic: `Gate 3 (Delivery): TRIUMPHANT — ${compositeSummary} >= threshold ${cfg.triumphantThreshold}; relationships above WARM_RELATIONSHIP_THRESHOLD.`,
    };
  }

  // Variant attribution: each dimension's "weighted shortfall" is how many
  // composite points it costs versus a hypothetical perfect 100 — weight *
  // (100 - subscore). This replaces the old two-way financial-vs-goodwill
  // comparison (which silently ignored morale/boardConfidence/honesty
  // entirely) with a proper dominant-cause read across all five dimensions.
  // See data/endings.json's variantSelectionNote for the full rationale.
  const shortfall = (weight: number, subscore: number) => weight * (100 - subscore);

  const financialShortfall = shortfall(w.financialSubscore, financialSubscore);
  const goodwillShortfall = shortfall(w.stakeholderGoodwill, goodwill);

  // "scrutiny" is only eligible when the player left EV-15's social-media
  // safety claim genuinely unresolved (CHOICE_EV-15's "Board-only briefing,
  // no public response" option — the only one of its three options that
  // doesn't actively defuse the claim). Without that flag, goodwill's
  // shortfall — whatever caused it — folds into the organisational bucket
  // instead of being mislabeled as an evidenced external-scrutiny event.
  const scrutinyEligible = state.flags.unresolved_public_scrutiny === true;

  const organisationalCandidates: Array<{ cause: OrganisationalDominantCause; value: number }> = [
    { cause: "boardConfidence", value: shortfall(w.boardConfidence, boardConfidence) },
    { cause: "teamMorale", value: shortfall(w.teamMorale, morale) },
    { cause: "honesty", value: shortfall(w.honesty, honesty) },
  ];
  if (!scrutinyEligible) {
    organisationalCandidates.push({ cause: "stakeholderGoodwill", value: goodwillShortfall });
  }
  const dominantOrganisational = organisationalCandidates.reduce((best, next) =>
    next.value > best.value ? next : best
  );
  const organisationalShortfall = dominantOrganisational.value;
  const scrutinyShortfall = scrutinyEligible ? goodwillShortfall : -1;

  // Ties resolve financial > organisational > scrutiny (stable, arbitrary
  // order — matches the old code's "ties resolve to financial" convention).
  let variant: PyrrhicVariant;
  let organisationalDominantCause: OrganisationalDominantCause | null = null;
  let attributionNote: string;
  if (financialShortfall >= organisationalShortfall && financialShortfall >= scrutinyShortfall) {
    variant = "financial";
    attributionNote = `financial shortfall ${financialShortfall.toFixed(1)} dominant`;
  } else if (organisationalShortfall >= scrutinyShortfall) {
    variant = "organisational";
    organisationalDominantCause = dominantOrganisational.cause;
    attributionNote = `organisational shortfall ${organisationalShortfall.toFixed(1)} dominant (cause: ${dominantOrganisational.cause}${scrutinyEligible ? "" : "; goodwill included, unresolved_public_scrutiny not set"})`;
  } else {
    variant = "scrutiny";
    attributionNote = `scrutiny shortfall ${scrutinyShortfall.toFixed(1)} dominant (unresolved_public_scrutiny set)`;
  }

  return {
    family: "PYRRHIC_VICTORY",
    variant,
    organisationalDominantCause,
    diagnostic: `Gate 3 (Delivery): PYRRHIC / ${variant} — ${compositeSummary} < threshold ${cfg.triumphantThreshold}; relationships above WARM_RELATIONSHIP_THRESHOLD; ${attributionNote}.`,
  };
}

/**
 * Synthetic, never-persisted condition flags derived from evaluateEnding —
 * mirrors state.ts's reportMismatchFlags/effectiveDialogueFlags pattern
 * exactly (pure readout of existing GameState, no separate storage). Not
 * merged into effectiveDialogueFlags itself to avoid a state.ts<->endings.ts
 * circular import (evaluateEnding needs findMostMaterialReportMismatch/
 * STARTING_BUDGET from state.ts) — GameRoot.tsx merges this in locally at
 * every effectiveDialogueFlags call site instead (see dialogueFlagsFor).
 * batch_released/batch_rejected reuse the exact flag names
 * DIALOGUE_ACT6_SCENE02 already authored against; contract_secured/
 * contract_lost likewise for ACT6_SCENE03's benefits readout — only how
 * they're computed changed (Gate 1 directly, not inferred from which of 7
 * endings fired). Exactly one ending_* family/variant flag is ever true.
 */
export function endingConditionFlags(state: GameState): Record<string, boolean> {
  const result = evaluateEnding(state);
  const isPyrrhic = result.endingFamily === "PYRRHIC_VICTORY";
  return {
    contract_secured: result.contractGateResult === "secured",
    contract_lost: result.contractGateResult === "lost",
    batch_released: result.batchResult === "released",
    batch_rejected: result.batchResult === "rejected",
    ending_TRIUMPHANT_LAUNCH: result.endingFamily === "TRIUMPHANT_LAUNCH",
    ending_PYRRHIC_financial: isPyrrhic && result.endingVariant === "financial",
    ending_PYRRHIC_political: isPyrrhic && result.endingVariant === "political",
    ending_PYRRHIC_scrutiny: isPyrrhic && result.endingVariant === "scrutiny",
    ending_PYRRHIC_organisational: isPyrrhic && result.endingVariant === "organisational",
    // One narrator beat within the organisational block is picked by
    // dominant cause — see OrganisationalDominantCause's doc comment.
    // Each already implies ending_PYRRHIC_organisational, so dialogue can
    // condition on just one of these four flags for that line.
    ending_PYRRHIC_organisational_boardConfidence:
      isPyrrhic && result.endingVariant === "organisational" && result.organisationalDominantCause === "boardConfidence",
    ending_PYRRHIC_organisational_teamMorale:
      isPyrrhic && result.endingVariant === "organisational" && result.organisationalDominantCause === "teamMorale",
    ending_PYRRHIC_organisational_honesty:
      isPyrrhic && result.endingVariant === "organisational" && result.organisationalDominantCause === "honesty",
    ending_PYRRHIC_organisational_stakeholderGoodwill:
      isPyrrhic && result.endingVariant === "organisational" && result.organisationalDominantCause === "stakeholderGoodwill",
    ending_PYRRHIC_recoverable_quality_failure: isPyrrhic && result.endingVariant === "recoverable_quality_failure",
    ending_CONTRACT_LOST: result.endingFamily === "CONTRACT_LOST",
    ending_BATCH_REJECTED: result.endingFamily === "BATCH_REJECTED",
  };
}

/**
 * Resolves Act 6's ending in one pass: Gate 1 (Contract) → Gate 2 (Quality,
 * only if secured) → Gate 3 (Delivery composite, only if released). Every
 * branch is documented in data/endings.json's gateThresholds — this
 * function contains no thresholds of its own, only the branching logic,
 * so recalibration after playtesting never needs a code change.
 */
export function evaluateEnding(state: GameState): EndingResult {
  const diagnostics: string[] = [];

  const contract = evaluateContractGate(state);
  diagnostics.push(contract.diagnostic);

  if (contract.result === "lost") {
    // The commercial outcome is already decided, but the facility still
    // runs its batch regardless — ACT6_SCENE02's control-room scene plays
    // out either way ("the batch can succeed; the business outcome
    // didn't" per the design brief), so Gate 2 still runs here purely to
    // populate batchResult for that scene's batch_released/batch_rejected
    // conditions. Its family suggestion is discarded — Contract Lost
    // always wins as the ending family once Gate 1 has failed, regardless
    // of how the batch itself turns out.
    const quality = evaluateQualityGate(state);
    diagnostics.push(`(Gate 2 still evaluated for batchResult only, contract already lost) ${quality.diagnostic}`);
    return {
      contractGateResult: "lost",
      batchResult: quality.batchResult,
      endingFamily: "CONTRACT_LOST",
      endingVariant: null,
      organisationalDominantCause: null,
      diagnostics,
    };
  }

  const quality = evaluateQualityGate(state);
  diagnostics.push(quality.diagnostic);

  if (quality.family) {
    // Rejected — either recoverable (Pyrrhic) or not (Batch Rejected).
    // Gate 3 never runs: "how well did you get there" is moot when the
    // core deliverable itself failed or only survived via recovery.
    return {
      contractGateResult: "secured",
      batchResult: quality.batchResult,
      endingFamily: quality.family,
      endingVariant: quality.family === "PYRRHIC_VICTORY" ? "recoverable_quality_failure" : null,
      organisationalDominantCause: null,
      diagnostics,
    };
  }

  const delivery = evaluateDeliveryComposite(state);
  diagnostics.push(delivery.diagnostic);

  return {
    contractGateResult: "secured",
    batchResult: "released",
    endingFamily: delivery.family,
    endingVariant: delivery.family === "PYRRHIC_VICTORY" ? delivery.variant : null,
    organisationalDominantCause: delivery.family === "PYRRHIC_VICTORY" ? delivery.organisationalDominantCause : null,
    diagnostics,
  };
}
